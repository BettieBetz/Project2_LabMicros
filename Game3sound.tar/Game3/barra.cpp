#include "barra.h"
#include "ball.h"
#include "game.h"
#include <QGraphicsScene>
#include <QKeyEvent>
#include <wiringPi.h>  //Para wiringpi
#include <QTimer>      //Para wiringpi


Barra::Barra()
{
    //Creacion de la plataforma
    //Barra * plataforma = new Barra ();
    //scene()->addItem(plataforma);

    // WIRING PI CODE SECTION
    QTimer *timer2 = new QTimer(this);
    connect (timer2, SIGNAL(timeout()), this, SLOT(actualizar_boton()));
    timer2 -> start(20);
    // //////////////////////
}

void Barra::keyPressEvent(QKeyEvent *event)
{
        if (event->key() == Qt::Key_Left){
        //movimiento hacia la izquierda de la plataforma
            if (pos().x() > 0){
            setPos(x()-5,y());}
        }//end if Key_Left

        else if (event->key() == Qt::Key_Right){
        //movimiento hacia la derecha de la plataforma
            if (pos().x() < 390) {
            setPos(x()+5,y());}
        }//end

}//end void


// WIRING PI CODE SECTION
void Barra::actualizar_boton(){

    if (digitalRead(2)==HIGH){  //Boton Izquierdo

        if (pos().x() > 0){
        setPos(x()-5,y());}
        digitalWrite(5,HIGH);
        digitalWrite(5,LOW);
    }
    if (digitalRead(6)==HIGH){ //Boton Derecho

        if (pos().x() < 390) {
        setPos(x()+5,y());}
        digitalWrite(5,HIGH);
        digitalWrite(5,LOW);
    }
}

// //////////////////////



