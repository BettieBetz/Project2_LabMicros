#ifndef BARRA_H
#define BARRA_H
#include <QGraphicsRectItem>
#include <QObject>



class Barra: public QObject ,public QGraphicsRectItem {
    Q_OBJECT

public:
    Barra();

public slots:
    void actualizar_boton();
    void keyPressEvent(QKeyEvent * event);


};
#endif // BARRA_H
