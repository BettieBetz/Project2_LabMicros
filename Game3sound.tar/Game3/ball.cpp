#include "ball.h"
#include "barra.h"
#include "blocks.h"
#include "bottom.h"
#include "wright.h"
#include "top.h"
#include "wleft.h"
#include "score.h"
#include "game.h"
#include "mainwindow.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QList>
#include <typeinfo>
#include <stdlib.h> //de aqui viene la funcion random
#include <QDebug>
#include <math.h>
#include <wiringPi.h>
#include <softTone.h>
#include <QThread>      //Libreria para hacer pausas a threads, detiene todo el proceso


int movX;
int movY;
int dir_movX = -1;
int dir_movY = -1;
int angulo_salida;


extern Game * game;

Ball::Ball() {
     //Construir el rectangulo
    setRect(0,0,5,5);
    generar_angulo();

    //actualizacion del movimiento de la pelota cada 50 milisegundos
     QTimer * timer = new QTimer ();
     connect(timer,SIGNAL(timeout()),this,SLOT(move()));
     timer -> start (35);
}//end Ball

void Ball::generar_angulo() {

    /*Se genera un angulo de salida aleatorio de 180° hacia arriba
     (desde -90° a 90°) */
    angulo_salida = rand() % 180;

    /*Se evalua el angulo de salida para determinar el tipo de
      de movimiento que va a adquirir */

    if((0<=angulo_salida)&&(angulo_salida<30)){
        dir_movX = -1;
        movX = 10;
        dir_movY = -1;
        movY = 4;    }

    else if((30<=angulo_salida)&&(angulo_salida<60)){
        dir_movX = -1;
        movX = 10;
        dir_movY = -1;
        movY = 6;    }

    else if((60<=angulo_salida)&&(angulo_salida<90)){
        dir_movX = -1;
        movX = 10;
        dir_movY = -1;
        movY = 8;    }

    else if(angulo_salida == 90){
        dir_movX = 0;
        movX = 10;
        dir_movY = -1;
        movY = 10;    }
    else if((90<=angulo_salida)&&(angulo_salida<120)){
        dir_movX = 1;
        movX = 10;
        dir_movY = -1;
        movY = 8;    }
    else if((120<=angulo_salida)&&(angulo_salida<150)){
        dir_movX = 1;
        movX = 10;
        dir_movY = -1;
        movY = 6;    }
    else if((150<=angulo_salida)&&(angulo_salida<=180)){
        dir_movX = 1;
        movX = 10;
        dir_movY = -1;
        movY = 4;    }


    qDebug() << "MovX: "<< movX << "  MovY:" << movY;

}//end generar angulo

void Ball::move() { 

     //Mueve la pelota hacia arriba
     setPos(x()+(movX*dir_movX),y()+(movY*dir_movY));

 QList<QGraphicsItem*> colliding_items = collidingItems();


 for (int i=0 , n = colliding_items.size(); i < n ; ++i ){
     if (typeid (*(colliding_items[i])) == typeid (Blocks)) {
         scene()->removeItem(colliding_items[i]);//elimina bloque de la escena
         game->score->increase();//incrementa el score
         rebote_techo();
         //scene()->removeItem(this);
         //delete the both
         delete colliding_items[i];//elimina el bloque por completo
         //delete this;

         //encender_LED();
         encender_SONIDO();

         return;}

     if (typeid (*(colliding_items[i])) == typeid (WLeft)){
         rebote_w_left();
         //encender_LED();
         return;}

     if (typeid (*(colliding_items[i])) == typeid (WRight)){
         rebote_w_right();
         //encender_LED();
         return;}

     if (typeid (*(colliding_items[i])) == typeid (Barra)){
         rebote_plataforma();
         //encender_LED();
         return;}

     if (typeid (*(colliding_items[i])) == typeid (Top)){
         rebote_techo();
         //encender_LED();
         return;}

     if (typeid (*(colliding_items[i])) == typeid (Bottom)){
         game->lives->decrease();
         scene()->removeItem(this);
         //Si pelota colisiona con el piso se elimina
         delete this;
         return;}
     }//end for
}//end move


void Ball::rebote_w_left()
{//posicion de la pared izquierda
    dir_movX = dir_movX * (-1);
    //qDebug() << "MovX: "<< movX << "  MovY:" << movY;
}

void Ball::rebote_w_right()
{//posicion de la pared derecha
    dir_movX = dir_movX * (-1);
    //qDebug() << "MovX: "<< movX << "  MovY:" << movY;
}

void Ball::rebote_techo()
{//posicion del techo
    dir_movY = dir_movY * (-1);
    //qDebug() << "MovX: "<< movX << "  MovY:" << movY;
}

void Ball::rebote_plataforma()
{//posicion de la plataforma
    dir_movY = dir_movY * (-1);
    //qDebug() << "MovX: "<< movX << "  MovY:" << movY;
}

void Ball::encender_LED()
{
    // //////////WiringPi test start////////////
    digitalWrite(5,HIGH);
    qDebug() << "Deberia encenderse el LED :D ";

    //QThread::msleep(500);

    digitalWrite(5,LOW);

    //system(command.toStdString().c_str());
    //digitalWrite(33,LOW);


    // //////////WiringPi test end////////////
}

void Ball::encender_SONIDO()
{
    // //////////WiringPi test start////////////
    softToneWrite(23,740);
    qDebug() << "Deberia encenderse el SONIDO :D ";

    QThread::msleep(500);

    softToneWrite(23,0);

    //system(command.toStdString().c_str());
    //digitalWrite(33,LOW);


    // //////////WiringPi test end////////////
}

