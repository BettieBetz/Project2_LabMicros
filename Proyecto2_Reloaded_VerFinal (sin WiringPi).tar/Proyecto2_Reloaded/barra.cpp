#include "barra.h"
#include "ball.h"
#include "game.h"
#include "pantallainicial.h"
#include "pantallafinal.h"
#include <QGraphicsScene>
#include <QKeyEvent>
#include <QDebug>

extern Game *game;
Pantallafinal *pantallafinal;

void Barra::tabla()
{
    //Creacion de la plataforma
    Barra * plataforma = new Barra ();
    scene()->addItem(plataforma);
}

void Barra::keyPressEvent(QKeyEvent *event)
{
        if (event->key() == Qt::Key_Left){
        //movimiento hacia la izquierda de la plataforma
            if (pos().x() > 0){
            setPos(x()-5,y());}
        }//end if Key_Left

        else if (event->key() == Qt::Key_Right){
        //movimiento hacia la derecha de la plataforma
            if (pos ().x() < 390) {
            setPos(x()+5,y());}
        }//end else if key_Right

        else if (event->key() == Qt::Key_X){
        //Tecla para continuar segun el modo en el que se encuentre.
            qDebug () << "Tecla X presionada";

            //Modales del juego
            if((modo==1) && activo){
                game->Inicio_Juego();}
            else if(modo==2 && activo){
                game->Inicio_Juego();}
            else if(modo==3 && activo){
                game->Inicio_Juego();}

        }//end else if key_X

        else if(event->key() == Qt::Key_Enter){
           game->Reinicio_Forzado_Total();
        }

}//end void
