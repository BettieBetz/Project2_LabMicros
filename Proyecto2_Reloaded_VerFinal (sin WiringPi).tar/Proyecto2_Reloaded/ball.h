#ifndef BALL_H
#define BALL_H
#include <QGraphicsRectItem>
#include <QObject>

class Ball: public QObject ,public QGraphicsRectItem {
    Q_OBJECT

public:
    Ball();
    int movX;
    int movY;
    int dir_movX;
    int dir_movY;
    int angulo_salida;
    int habilitar_movXY;

public slots:
    void move ();    
    void rebote_w_left();
    void rebote_w_right();
    void rebote_techo();
    void rebote_plataforma();
    void generar_angulo();
};
#endif // BALL_H
