#ifndef BARRA_H
#define BARRA_H
#include <QGraphicsRectItem>
#include <QObject>

class Barra: public QObject ,public QGraphicsRectItem {
    Q_OBJECT

public:
    void tabla ();
    int modo; //1: Inicio Juego, 2: Caida pelota al suelo, 3: Fin del juego
    bool activo;
    void keyPressEvent(QKeyEvent * event);

};
#endif // BARRA_H
