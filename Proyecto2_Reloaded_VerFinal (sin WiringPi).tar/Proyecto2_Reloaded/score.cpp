#include "score.h"
#include <QFont>


Score::Score(QGraphicsTextItem *parent): QGraphicsTextItem(parent) {
    //inicializa la puntuacion en 0
     score = 0;

    //escribe el texto
    setPlainText(QString("Puntuacion: ") + QString::number(score));
    setDefaultTextColor (Qt::blue);
    setFont(QFont ("ubuntu",12));
}

void Score::increase() {
   score++;
   setPlainText(QString("Puntuacion: ") + QString::number(score));
}

void Score::reset_score()
{
    score = 0;
    setPlainText(QString("Puntuacion: ") + QString::number(score));
}
