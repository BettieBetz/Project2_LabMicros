#include "pantallainicial.h"

#include <QApplication>



int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    PantallaInicial w;
    w.show();

    return a.exec();
}
