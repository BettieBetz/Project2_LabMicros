#ifndef GAME_H
#define GAME_H

#include "wleft.h"
#include "wright.h"
#include "top.h"
#include "bottom.h"
#include "blocks.h"
#include "barra.h"
#include "ball.h"
#include "score.h"
#include "lives.h"
#include "pantallafinal.h"
#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsView>
#include <QTimer>
#include <QWidget>
#include <QGraphicsPixmapItem>

class Game: public QGraphicsRectItem {

public:
    Game(QWidget * parent=0);
    QGraphicsScene * scene;
    QGraphicsView * view;
    Score * score;
    Lives * lives;
    Barra * plt;
    Ball * bl;
    WLeft * wf;
    Top * top;
    WRight * wr;
    Bottom * bottom;
    QString nombre_usuario;
    void EscrituraTextos();
    void Dibujar_Bloques();
    void Redibujar_Bloques();
    void Inicio_Juego();
    void Caida_Suelo();
    void Fin_Juego();
    void Gano_Juego();
    void Reinicio_Forzado_Total();

private:
    Pantallafinal *pantallafinal;  //Insercion para mostrar la pantalla final desde esta ventana

};

#endif // GAME_H
