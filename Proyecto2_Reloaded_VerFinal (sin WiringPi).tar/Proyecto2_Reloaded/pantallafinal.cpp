#include "pantallafinal.h"
#include "ui_pantallafinal.h"
#include <QThread>
#include <QApplication>
#include <QKeyEvent>
#include <QGraphicsScene>

Pantallafinal::Pantallafinal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Pantallafinal)
{
    ui->setupUi(this);

}

Pantallafinal::~Pantallafinal()
{
    delete ui;
}

void Pantallafinal::keyPressEvent(QKeyEvent *event2){

     if (event2->key() == Qt::Key_X){
        Pantallafinal::close();
        QApplication::quit();}
}

