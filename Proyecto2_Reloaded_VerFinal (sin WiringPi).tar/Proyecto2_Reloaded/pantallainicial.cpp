#include "pantallainicial.h"
#include "ui_pantallainicial.h"
#include "game.h"
#include <QDebug>   //Include para pruebas
#include <QThread>  //Include para tiempo de espera en pruebas
#include <QApplication>

Game *game;

PantallaInicial::PantallaInicial(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PantallaInicial)
{
    ui->setupUi(this);    
}

PantallaInicial::~PantallaInicial()
{
    delete ui;
}


//Accion que se realiza al hacer click en el boton "Jugar"
void PantallaInicial::on_actionbutton_jugar_clicked()
{
    game = new Game();

    game->nombre_usuario = ui->editext_nombre_usuario->text();

    game->Dibujar_Bloques();
    game->EscrituraTextos();

    PantallaInicial::hide(); //Esconde la pantalla inicial para dar paso a la nueva pantalla

    PantallaInicial::close();  //Cierra la pantalla inicial

    game -> show();

    //pantallafinal = new Pantallafinal(this);    // ### Linea para pruebas//No Fundamental para la compilacion final//
    //pantallafinal -> show();                    // ### Linea para pruebas//No Fundamental para la compilacion final//
}
