#ifndef PANTALLAFINAL_H
#define PANTALLAFINAL_H

#include <QDialog>
#include <QKeyEvent>

namespace Ui {
class Pantallafinal;
}

class Pantallafinal : public QDialog
{
    Q_OBJECT

public:
    explicit Pantallafinal(QWidget *parent = 0);
    ~Pantallafinal();
    void FinalizarJuego();
    void keyPressEvent(QKeyEvent *event2);

private slots:

private:
    Ui::Pantallafinal *ui;
};

#endif // PANTALLAFINAL_H
