#include <QApplication>
#include <QGraphicsScene>
//#include <QGraphicsRectItem>
#include "MyRect.h"
#include <QGraphicsView>

/*
Testeo de diferentes codigos para la utilizacion en el proyecto 2

Recursos utilizados
- QGraphicsScene
- QGraphicsItem (QGraphicsRectItem)
- QGraphicsView
- keyPressEvent()
- QKeyEvent
- QDebug
- QTimer
- Señales y campos (signals and slots)
- QObject and Q_OBJECT macro


*/

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    //////////////////////////////////////////////////////
    //Inicio del codigo
    //////////////////////////////////////////////////////


    //Creacion de una escena
    QGraphicsScene * scene = new QGraphicsScene();

    //Creacion de un item para poner en escena
    MyRect * player = new MyRect();
    player -> setRect(0,0,100,100);

    //Agregar el item a la escena
    scene -> addItem(player);

    //Hacer que un item sea enfocado para una accion
    player -> setFlag(QGraphicsItem::ItemIsFocusable);    //Hacer del rectangulo un objeto "focusable"
    player -> setFocus(); //Enfocar la escena en el objeto rectangulo

    //Agregar una vista para ver la escena
    QGraphicsView * view = new QGraphicsView(scene);
    view -> setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff); //Quitar el scrollbar horizontal
    view -> setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);   //Quitar el scrollbar vertical


    //Mostrar la escena
    view -> show();

    //Establecer el tamaño de la escena y del view
    view -> setFixedSize(800,600);
    scene -> setSceneRect(0,0,800,600);

    player -> setPos(view->width()/2, view->height() - player->rect().height());



    //////////////////////////////////////////////////////
    //Fin del codigo
    //////////////////////////////////////////////////////

    return a.exec();
}
