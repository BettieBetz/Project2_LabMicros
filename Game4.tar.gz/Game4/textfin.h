#ifndef TEXTFIN_H
#define TEXTFIN_H
#include <QGraphicsTextItem>
#include <QFont>

class Text_Fin : public QGraphicsTextItem{
public:
    Text_Fin(QGraphicsTextItem * parent=0);
};

#endif // TEXTFIN_H
