#include "textfin.h"

Text_Fin::Text_Fin(QGraphicsTextItem *parent) : QGraphicsTextItem(parent){
    //Escribe Texto
    setPlainText(QString("Gracias por jugar micronoid\n") + QString("\n Grupo: 3 \n") + QString("Chaves Vasquez Anthony - 201048654 \n") + QString("Hidalgo Soto Laura - 200956890 \n") + QString("Murillo Soto Carlos - 20338697 \n") + QString("Rivera Arrieta Irene - 201121803 \n"));
    setDefaultTextColor (Qt::black);
    setFont(QFont ("times",12));
}
