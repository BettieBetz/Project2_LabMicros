#ifndef SCREEN_INICIAL_H
#define SCREEN_INICIAL_H

#include <textinicial.h>
#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsView>
#include <QTimer>
#include <QWidget>
#include <QGraphicsPixmapItem>

class Screen_Inicio: public QGraphicsRectItem{

public:
    Screen_Inicio(QWidget * parent = 0);
    QGraphicsScene * scene_inicial;
    QGraphicsView * view_inicial;
    Text_Inicial * texto_inicial;

public slots:
    void teclado(unsigned char tcl);
};

#endif // SCREEN_INICIAL_H
