//Se importan todas las librerias necesarias
//#include "mainwindow.h"
#include "screen_inicio.h"
#include "textinicial.h"

#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsTextItem>
#include <QGraphicsView>
#include <QTimer>
#include <QWidget>
#include <QFont>
#include <QProcess>
#include <QThread> //Libreria para hacer pausas a threads, detiene todo el proceso

int inplayer;
char player[inplayer];

Screen_Inicio::Screen_Inicio(QWidget *parent){

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//&&&&&&&&&&&  DEFINICION DE LA ESCENA &&&&&&&&&&&&&&&&&&&&&&&&

    //create a scene
    scene_inicial = new QGraphicsScene();


    //Creacion de view para visualizar la escena
    view_inicial = new QGraphicsView (scene_inicial);


    //  Show the view
    view_inicial->show();
    view_inicial->setFixedSize(850,600);
    scene_inicial->setSceneRect(0,0,550,600);


//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//&&&&&&&&&&& DEFINIENDO LOS OBJETOS EN LA ESCENA &&&&&&&&&

    //Creación del texto de la pantalla de inicio
    texto_inicial = new Text_Inicial();
    texto_inicial->setPos(100,100);
    scene_inicial->addItem(texto_inicial);

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    //Se obtiene el nombre de usuario


    QThread::msleep(5000);
    view_inicial->close();

}//end ScreenInicio

void Screen_Inicio::teclado(unsigned char tcl){

    if((tcl==32) || ((tcl>=97)&&(tcl<=122)) || ((tcl>=48)&&(tcl<=90))){
//abarca las letras "normales" (mayuscula y minuscula) y numeros en valores ASCII
        player[inplayer++] = tcl;
        player[inplayer] = '\0';//indica el fin de la linea
    }//end if

    else if (tcl == 8){
        //si presiona enter
        player[--inplayer] = '\0';
    }

}//end void
