#include "textinicial.h"

Text_Inicial::Text_Inicial(QGraphicsTextItem *parent) : QGraphicsTextItem(parent){
    //Escribe Texto
    setPlainText(QString("Bienvenido a Micronoid \n") + QString("EL-4313 Laboratorio de Estructura de Microprocesadores \n") + QString("Ingrese el nombre del jugador, luego presione ENTER"));
    setDefaultTextColor (Qt::black);
    setFont(QFont ("times",12));
}
