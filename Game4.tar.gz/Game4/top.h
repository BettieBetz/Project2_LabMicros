#ifndef TOP_H
#define TOP_H
#include <QGraphicsRectItem>
#include <QObject>


class Top: public QObject ,public QGraphicsRectItem {
    Q_OBJECT

public:
    void techo ();
};

#endif // TOP_H
