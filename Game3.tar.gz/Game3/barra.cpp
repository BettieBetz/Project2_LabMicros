#include "barra.h"
#include "ball.h"
#include <QGraphicsScene>
#include <QKeyEvent>

void Barra::tabla()
{
    //Creacion de la plataforma
    Barra * plataforma = new Barra ();
    scene()->addItem(plataforma);
}

void Barra::keyPressEvent(QKeyEvent *event)
{
        if (event->key() == Qt::Key_Left){
        //movimiento hacia la izquierda de la plataforma
            if (pos().x() > 0){
            setPos(x()-5,y());}
        }//end if Key_Left

        else if (event->key() == Qt::Key_Right){
        //movimiento hacia la derecha de la plataforma
            if (pos ().x() < 390) {
            setPos(x()+5,y());}
        }//end else if key_Right

}//end void
