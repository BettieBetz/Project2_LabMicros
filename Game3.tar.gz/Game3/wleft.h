#ifndef WLEFT_H
#define WLEFT_H
#include <QGraphicsRectItem>
#include <QObject>


class WLeft: public QObject ,public QGraphicsRectItem {
    Q_OBJECT

public:
    void pared_iz ();
};
#endif // WLEFT_H
