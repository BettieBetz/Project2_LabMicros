#ifndef BALL_H
#define BALL_H
#include <QGraphicsRectItem>
#include <QObject>

class Ball: public QObject ,public QGraphicsRectItem {
    Q_OBJECT

public:
    Ball();

public slots:
    void move ();
    void movimiento_inicial();
    void movimiento_pared_izquierda();
    void movimiento_pared_derecha();
    void movimiento_techo();
    void movimiento_paleta();
};
#endif // BALL_H
