#include "ball.h"
#include "palette.h"
#include "blocks.h"
#include "wall_botton.h"
#include "wall_right.h"
#include "wall_top.h"
#include "wall_left.h"
#include "score.h"
#include "game.h"
#include "mainwindow.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QList>
#include <typeinfo>
#include <stdlib.h> //de aqui viene la funcion random
#include <QDebug>

int movX;
int movY;
int dir_movX = -1;
int dir_movY = -1;
int angulo_salida;

extern Game * game ;

Ball::Ball() {
     //Construir el rectangulo
    setRect(0,0,5,5);

    //conexion
     QTimer * timer = new QTimer ();
     connect(timer,SIGNAL(timeout()),this,SLOT(move()));
     timer -> start (50);
}//end Ball

void Ball::move() {

     movimiento_paleta();

     angulo_salida = rand() % 180;

     if(angulo_salida == 90){
         dir_movX = 0;}
     else if(angulo_salida < 90){
         dir_movX = -1;}
     else if(angulo_salida > 90){
         dir_movX = 1;
     }

     movX = rand() % 20;
     movY = rand() % 20;

     //Move the bullet up
     setPos(x()+(movX*dir_movX),y()+(movY*dir_movY));

 QList<QGraphicsItem*> colliding_items = collidingItems();


 for (int i=0 , n = colliding_items.size(); i < n ; ++i ){
     if (typeid (*(colliding_items[i])) == typeid (Blocks)) {
         scene()->removeItem(colliding_items[i]);//elimina bloque de la escena
         game->score->increase();//incrementa el score
         movimiento_techo();
         //scene()->removeItem(this);
         //delete the both
         delete colliding_items[i];//elimina el bloque por completo
         //delete this;
         return;}
     if (typeid (*(colliding_items[i])) == typeid (Wall_left)){
         movimiento_pared_izquierda();
         return;}
     if (typeid (*(colliding_items[i])) == typeid (Wall_botton)){
         game->lives->decrease();
         scene()->removeItem(this);
         //Si pelota colisiona con el piso se elimina
         delete this;
         return;}
 }//end for


}//end move

void Ball::movimiento_inicial()
{//posicion inicial de la pelota
    setPos(x()-10,y()-10);
}

void Ball::movimiento_pared_izquierda()
{//posicion de la pared izquierda
    setPos(x()+10,y()-10);
}

void Ball::movimiento_pared_derecha()
{//posicion de la pared derecha
    setPos(x()-10,y()+10);
}

void Ball::movimiento_techo()
{//posicion del techo
    setPos(x()+20,y()+20);
}

void Ball::movimiento_paleta()
{//posicion de la plataforma
    setPos(x(),y()-10);
}
