#include "Bullet.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QDebug>
#include <qglobal.h>
#include <QtGlobal>
#include <stdlib.h> //de aqui viene la func. random
#include <wiringPi.h>

int movX;
int movY;
int dir_movX = -1;
int dir_movY = -1;
int angulo_salida;


Bullet::Bullet(){

    //Construir el rectangulo
    setRect(0,0,5,5);

    //Conexion
    QTimer * timer = new QTimer();
    connect(timer, SIGNAL(timeout()),this,SLOT(move()));

    timer->start(50);
}

void Bullet::move(){

    angulo_salida = rand() % 180;

    if(angulo_salida == 90){
        dir_movX = 0;
    }
    else if(angulo_salida < 90){
        dir_movX = -1;
    }
    else if(angulo_salida > 90){
        dir_movX = 1;
    }

    movX = rand() % 20;
    movY = rand() % 20;

    //Move the bullet up
    setPos(x()+(movX*dir_movX),y()+(movY*dir_movY));

    if(pos().y()<0){
        scene()->removeItem(this);
        delete this;
        qDebug() << "Bullet Deleted!";
    }
}
