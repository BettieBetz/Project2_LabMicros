#ifndef BOTTOM_H
#define BOTTOM_H
#include <QGraphicsRectItem>
#include <QObject>


class Bottom: public QObject ,public QGraphicsRectItem {
    Q_OBJECT

public:
    void piso ();
};
#endif // BOTTOM_H
