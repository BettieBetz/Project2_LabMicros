#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "screenpx.h"

#include "game.h"

#include <QDebug>

int n =0;//Se utiliza para evitar que la ventana se abra más de una vez

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_username_editingFinished()
{

    if (n == 0){//Evita que la siguiente ventana se abra más de una vez
        n++;
        QString username = ui->username->text();//Se guarda el nombre de usuario en la variable string username

        qDebug()<<username<<n;//PARA PRUEBAS

        //código para cerrar ventana actual y llamar a la siguiente
        close();
        pressx = new ScreenPx(this);
        pressx->show();}

    else{
        close();
    }

}
