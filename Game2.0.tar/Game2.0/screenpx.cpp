#include "screenpx.h"
#include "ui_screenpx.h"

#include <QDebug>

ScreenPx::ScreenPx(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ScreenPx)
{
    ui->setupUi(this);
}

ScreenPx::~ScreenPx()
{
    delete ui;
}


/* QString tcl_x = ui->tclx->text();

    if (tcl_x == "x" || tcl_x == "X"){
        qDebug()<<"x press";

        hide();
        juego = new Game();
        juego->show();
    }*/

void ScreenPx::on_tclx_textChanged(const QString &arg1)
{
    QString tcl_x = ui->tclx->text();

        if (tcl_x == "x" || tcl_x == "X"){
            qDebug()<<tcl_x;

            close();
        }
}
