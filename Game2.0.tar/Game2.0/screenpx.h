#ifndef SCREENPX_H
#define SCREENPX_H

#include <QDialog>


namespace Ui {
class ScreenPx;
}

class ScreenPx : public QDialog
{
    Q_OBJECT

public:
    explicit ScreenPx(QWidget *parent = 0);
    ~ScreenPx();

private slots:
    void on_tclx_textChanged(const QString &arg1);

private:
    Ui::ScreenPx *ui;
};

#endif // SCREENPX_H
