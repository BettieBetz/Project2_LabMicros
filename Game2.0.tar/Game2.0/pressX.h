#ifndef PRESSX_H
#define PRESSX_H

#include "mainwindow.h"
#include "wleft.h"
#include "wright.h"
#include "top.h"
#include "bottom.h"
#include "blocks.h"
#include "barra.h"
#include "ball.h"
#include "score.h"
#include "lives.h"
#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsView>
#include <QTimer>
#include <QWidget>
#include <QGraphicsPixmapItem>

class PressX: public QGraphicsRectItem {

public:
    PressX(QWidget * parent=0);
    QGraphicsScene * scene2;
    QGraphicsView * view2;
    Score * score2;
    Lives * lives2;
    Barra * plt2;
    Ball * bl2;
    WLeft * wf2;
    Top * top2;
    WRight * wr2;
    Bottom * bottom2;;
};

#endif // GAME_H
