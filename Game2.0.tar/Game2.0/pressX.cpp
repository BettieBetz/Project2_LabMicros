//Se importan todas las librerias necesarias
//#include "mainwindow.h"
#include "wleft.h"
#include "wright.h"
#include "top.h"
#include "bottom.h"
#include "blocks.h"
#include "barra.h"
#include "ball.h"
#include "score.h"
#include "lives.h"
#include "pressX.h"

#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsTextItem>
#include <QGraphicsView>
#include <QTimer>
#include <QWidget>
#include <QFont>
#include <QProcess>



PressX::PressX(QWidget *parent)
{
    //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    //&&&&&&&&&&&  DEFINICION DE LA ESCENA &&&&&&&&&&&&&&&&&&&&&&&&
          //create a scene
           scene2 = new QGraphicsScene();

           //Creacion de view para visualizar la escena
           view2 = new QGraphicsView (scene2);

        //  Show the view
             view2->show();
             view2->setFixedSize(850,600);
             scene2->setSceneRect(0,0,550,600);


      //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
      //&&&&&&&&&&& DEFINIENDO LOS OBJETOS EN LA ESCENA &&&&&&&&&

      //Create the Score
            score2 = new Score();
            score2-> setPos(400,500);
            scene2->addItem(score2);

      //Creacion de las "vidas"
            lives2 = new Lives();
            lives2-> setPos(30,500);
            scene2->addItem(lives2);

      //creacion de la plataforma, se agrega a escena y se le da atributos de objeto movil
           plt2 = new Barra ();
           plt2 -> setRect(15,525,100,10);
           plt2 -> setPos(+190,0);
           scene2->addItem(plt2);

      //Se crea la bola y se agrega a la escena
           bl2 = new Ball ();
           bl2->setRect(250,514 ,10,10);
           bl2 -> setPos(0,0);
           scene2->addItem(bl2);

    //Creacion de la pared izq, se pone en escena.
            wf2 = new WLeft ();
            wf2->setRect(0,0,15,600);
            scene2->addItem(wf2);

    //Crear la pared der., se agrega a la escena
        wr2 = new WRight ();
        wr2->setRect(505,0,15,600);
        scene2->addItem(wr2);

    //Crea el techo, se pone en escena.
        top2 = new Top ();
        top2->setRect(15,0,490,15);
        scene2->addItem(top2);

    //Crea el  piso, se pone en escena
        bottom2 = new Bottom ();
        bottom2->setRect(15,585,490,15);
        scene2->addItem(bottom2);

        //Crea los bloques, se ponen en escena
                for (int i=0; i<66 ; ++i ) {
                    if (i == 0){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (15,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 1 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (53,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 2 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (91,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 3 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (127,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 4 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (165,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 5 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (203,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 6 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (241,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 7 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (277,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 8 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (315,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 9 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (353,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 10 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (391,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 11 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (429,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 12 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (467,30,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 13){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (15,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 14 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (53,65,37,34);
                       scene2->addItem(blk_i); }
                   else if (i == 15 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (91,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 16 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (127,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 17 ){
                      Blocks * blk_i = new Blocks ();
                      blk_i ->setRect (165,65,37,34);
                      scene2->addItem(blk_i);}
                   else if (i == 18 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (203,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 19 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (241,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 20 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (277,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 21 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (315,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 22 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (353,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 23 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (391,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 24 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect(429,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 25 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (467,65,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 26){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (15,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 27 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (53,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 28 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (91,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 29 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (127,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 30 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (165,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 32 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (203,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 33 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (241,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 34 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (277,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 35 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (315,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 36 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (353,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 37 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (391,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 38 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (429,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 39 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (467,100,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 40){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (15,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 41 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (53,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 42 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (91,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 43 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (127,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 44 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (165,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 45 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (203,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 46 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (241,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 47 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (277,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 48 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (315,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 49 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (353,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 50 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (391,135,37,34);
                       scene2->addItem(blk_i); }
                   else if (i == 51 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (429,135,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 52 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (467,135,37,34);
                       scene2->addItem(blk_i); }
                   else if (i == 53){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (15,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 54 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (53,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 55 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (91,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 56 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (127,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 57 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (165,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 58 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (203,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 59 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (241,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 60 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (277,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 61 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (315,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 62 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (353,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 63 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (391,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 64 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (429,170,37,34);
                       scene2->addItem(blk_i);}
                   else if (i == 65 ){
                       Blocks * blk_i = new Blocks ();
                       blk_i ->setRect (467,170,37,34);
                       scene2->addItem(blk_i);}
                }//endif
                //Finaliza la creacion de los bloques

}//"end preesX"
