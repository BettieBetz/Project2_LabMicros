#include "username.h"
#include <QDebug>
#include <QString>
#include <QChar>

QString player;
int inplayer = 0;

bool UserName::eventFilter(QObject * obj, QEvent * event){
    if(event->type()==QEvent::KeyPress){
        QKeyEvent* key = static_cast<QKeyEvent*>(event);
        if((key->key()==Qt::Key_Enter)||((key->key()>=Qt::Key_A)&&(key->key()<=Qt::Key_Z))||(key->key()==Qt::Key_Space)||((key->key()>=Qt::Key_0)&&(key->key()<=Qt::Key_9))){

            //Se hace la conversión de key->key() a un string
            char tcl_t = static_cast<char>(key->key());
            QChar(char(tcl_t));
            QString tcl = QChar (tcl_t);

            //Se agrega la letra al nombre de usuario
            player.append(tcl);
            qDebug()<<player;
        }//end if2
        else{
            return QObject::eventFilter(obj, event);}
        return true;
    }//end if1
    else{
        return QObject::eventFilter(obj, event);
    }
return false;
}
