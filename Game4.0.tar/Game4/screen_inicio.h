#ifndef SCREEN_INICIAL_H
#define SCREEN_INICIAL_H

#include "textinicial.h"
#include "username.h"
#include "text_pressx.h"
#include "pressx.h"

#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsTextItem>
#include <QGraphicsPixmapItem>
#include <QGraphicsView>
#include <QWidget>
#include <QKeyEvent>
#include <QObject>
#include <QFont>
#include <QProcess>
#include <QEvent>
#include <QThread> //Libreria para hacer pausas a threads, detiene todo el proceso

class Screen_Inicio: public QGraphicsRectItem{

public:
    Screen_Inicio(QWidget * parent = 0);
    QGraphicsScene * scene_inicial;
    QGraphicsView * view_inicial;
    Text_Inicial * texto_inicial;
    Text_PressX * tpressX;


};

#endif // SCREEN_INICIAL_H
