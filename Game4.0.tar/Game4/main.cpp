#include <QApplication>
#include "game.h"
#include "screen_inicio.h"
#include "screen_fin.h"

Screen_Inicio * inicio;
Game * game;
Screen_Fin * fin;


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    //Se muestra la pantalla inicio
    inicio = new Screen_Inicio();
    inicio -> show();

    //Se muestra la pantalla de juego
    //game = new Game();
    //game -> show ();

    //Se muestra la pantalla final
    //fin = new Screen_Fin();
    //fin -> show();

    return a.exec();
}
