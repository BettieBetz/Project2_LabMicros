#ifndef PRESSX_H
#define PRESSX_H

#include <QGraphicsRectItem>
#include <QObject>
#include <QEvent>
#include <QKeyEvent>
#include <QWidget>

class PressX : public QObject{
    Q_OBJECT
public:
    int px;
    bool eventFilter(QObject* obj, QEvent* event);
};

#endif // PRESSX_H
