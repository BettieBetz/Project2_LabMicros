//Se importan todas las librerias necesarias
#include "screen_inicio.h"
#include "game.h"

#include <QDebug>


Screen_Inicio::Screen_Inicio(QWidget *parent){

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//&&&&&&&&&&&  DEFINICION DE LA ESCENA &&&&&&&&&&&&&&&&&&&&&&&&

    //create a scene
    scene_inicial = new QGraphicsScene();


    //Creacion de view para visualizar la escena
    view_inicial = new QGraphicsView (scene_inicial);


    //  Show the view
    view_inicial->show();
    view_inicial->setFixedSize(850,600);
    scene_inicial->setSceneRect(0,0,550,600);


//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//&&&&&&&&&&& DEFINIENDO LOS OBJETOS EN LA ESCENA &&&&&&&&&

    //Creación del texto de la pantalla de inicio
    texto_inicial = new Text_Inicial();
    texto_inicial->setPos(100,100);
    scene_inicial->addItem(texto_inicial);

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    //Se obtiene el nombre de usuario
    UserName* tcl = new UserName();
    scene_inicial->installEventFilter(tcl);

    //se agrega texto de presionar la tecla x
    tpressX = new Text_PressX();
    tpressX->setPos(100,250);
    scene_inicial->addItem(tpressX);

    //Se obtiene la tecla X presionada
    PressX* tcl_x = new PressX();
    scene_inicial->installEventFilter(tcl_x);


    PressX* to = new PressX();
    int num = to->px;
   qDebug()<<"hi"<<num;

    //QThread::msleep(5000);
    //view_inicial->close();

}//end ScreenInicio
