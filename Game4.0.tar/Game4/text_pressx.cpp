#include "text_pressx.h"

Text_PressX::Text_PressX(QGraphicsTextItem *parent) : QGraphicsTextItem(parent){
    setPlainText(QString("Presione X para continuar \n"));
    setDefaultTextColor (Qt::black);
    setFont(QFont ("times",14));
}
