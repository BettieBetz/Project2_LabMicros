#ifndef USERNAME_H
#define USERNAME_H

#include <QGraphicsRectItem>
#include <QObject>
#include <QEvent>
#include <QKeyEvent>
#include <QWidget>

class UserName : public QObject{
    Q_OBJECT
public:
    bool eventFilter(QObject* obj, QEvent* event);
};

#endif // USERNAME_H
