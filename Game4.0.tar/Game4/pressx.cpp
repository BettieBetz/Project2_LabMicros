#include "pressx.h"
#include "game.h"
#include "screen_inicio.h"

#include <QDebug>

Game * game1;/*
Screen_Inicio * pi;*/
PressX * w;

bool PressX::eventFilter(QObject * obj, QEvent * event){
    if(event->type()==QEvent::KeyPress){
        QKeyEvent* key = static_cast<QKeyEvent*>(event);
        if((key->key()==Qt::Key_X)){

            int px = 2;


            //pi->close();

            //Se muestra la pantalla de juego
            //game1 = new Game();
            //game1 -> show ();

        }//end if2
        else{
            return QObject::eventFilter(obj, event);}
        return true;
    }//end if1
    else{
        return QObject::eventFilter(obj, event);
    }
return false;
}
