#include "wleft.h"
#include <QGraphicsScene>
#include <QKeyEvent>

void WLeft::pared_iz()
{
    //Crea la pared_izquierda
    WLeft * wleft = new WLeft ();
    scene()->addItem(wleft);
}
