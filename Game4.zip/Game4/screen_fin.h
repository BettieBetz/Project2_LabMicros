#ifndef SCREEN_FINL_H
#define SCREEN_FIN_H

#include <textfin.h>
#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsView>
#include <QTimer>
#include <QWidget>
#include <QGraphicsPixmapItem>

class Screen_Fin: public QGraphicsRectItem{

public:
    Screen_Fin(QWidget * parent = 0);
    QGraphicsScene * scene_fin;
    QGraphicsView * view_fin;
    Text_Fin * texto_fin;

};

#endif // SCREEN_FIN_H
