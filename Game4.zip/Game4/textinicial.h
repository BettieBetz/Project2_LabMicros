#ifndef TEXTINICIAL_H
#define TEXTINICIAL_H
#include <QGraphicsTextItem>
#include <QFont>

class Text_Inicial : public QGraphicsTextItem{
public:
    Text_Inicial(QGraphicsTextItem * parent=0);
};

#endif // TEXTINICIAL_H
