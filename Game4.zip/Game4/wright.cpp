#include "wright.h"
#include <QGraphicsScene>
#include <QKeyEvent>


void WRight::pared_right()
{
    //Crea la pared_derecha
    WRight * wright = new WRight ();
    scene()->addItem(wright);
}
