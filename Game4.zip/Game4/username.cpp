#include "username.h"
#include <QDebug>


bool UserName::eventFilter(QObject * obj, QEvent * event){
    if(event->type()==QEvent::KeyPress){
        QKeyEvent* key = static_cast<QKeyEvent*>(event);
        if((key->key()==Qt::Key_Enter)||(key->key()==Qt::Key_Return)){
            //enter or return was pressed
            qDebug()<<"se presiono tecla";
        }//end if2
        else{
            return QObject::eventFilter(obj, event);}
        return true;
    }//end if1
    else{
        return QObject::eventFilter(obj, event);
    }
return false;
}

/*
void Screen_Inicio::keyPressEvent(QKeyEvent *event){

    event->key() = tcl;

    if(tcl == Qt::Key_X){
        qDebug()<<"Presionó la tecla X ";
    }
    if((event->key()==32) || ((event->key() >=97)&&(event->key()<=122)) || ((tcl>=48)&&(tcl<=90))){
//abarca las letras "normales" (mayuscula y minuscula) y numeros en valores ASCII
        player[inplayer++] = event->key;
        player[inplayer] = '\0';//indica el fin de la linea
    }//end if

    else if (tcl == 8){
        //si presiona enter
        player[--inplayer] = '\0';
    }

}//end void*/
