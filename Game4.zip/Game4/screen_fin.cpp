//Se importan todas las librerias necesarias
//#include "mainwindow.h"
#include "screen_fin.h"
#include "textfin.h"

#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsTextItem>
#include <QGraphicsView>
#include <QTimer>
#include <QWidget>
#include <QFont>
#include <QProcess>
#include <QThread> //Libreria para hacer pausas a threads, detiene todo el proceso



Screen_Fin::Screen_Fin(QWidget *parent){

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//&&&&&&&&&&&  DEFINICION DE LA ESCENA &&&&&&&&&&&&&&&&&&&&&&&&

    //create a scene
    scene_fin = new QGraphicsScene();

    //Creacion de view para visualizar la escena
    view_fin = new QGraphicsView (scene_fin);

    //  Show the view
    view_fin->show();
    view_fin->setFixedSize(850,600);
    scene_fin->setSceneRect(0,0,550,600);


//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
//&&&&&&&&&&& DEFINIENDO LOS OBJETOS EN LA ESCENA &&&&&&&&&

    //Creación del texto de la pantalla de inicio
    texto_fin = new Text_Fin();
    texto_fin->setPos(100,100);
    scene_fin->addItem(texto_fin);

//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

    //Se muestra la información del procesador

    //QThread::msleep(5000);
    //view_inicial->close();

}
