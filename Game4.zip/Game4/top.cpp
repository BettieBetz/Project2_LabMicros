#include "top.h"
#include <QGraphicsScene>
#include <QKeyEvent>


void Top::techo()
{//Crea techo
    Top * top = new Top ();
    scene()->addItem(top);
}
