#include "pressx.h"

#include <QDebug>


bool PressX::eventFilter(QObject * obj, QEvent * event){
    if(event->type()==QEvent::KeyPress){
        QKeyEvent* key = static_cast<QKeyEvent*>(event);
        if((key->key()==Qt::Key_X)){
            //enter or return was pressed
            qDebug()<<"se presiono tecla X";
        }//end if2
        else{
            return QObject::eventFilter(obj, event);}
        return true;
    }//end if1
    else{
        return QObject::eventFilter(obj, event);
    }
return false;
}
