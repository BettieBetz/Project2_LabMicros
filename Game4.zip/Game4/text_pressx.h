#ifndef TEXT_PRESSX_H
#define TEXT_PRESSX_H

#include <QGraphicsTextItem>
#include <QFont>

class Text_PressX : public QGraphicsTextItem{
public:
    Text_PressX(QGraphicsTextItem * parent = 0);
};

#endif // TEXT_PRESSX_H
