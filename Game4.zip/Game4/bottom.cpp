#include "bottom.h"
#include <QGraphicsScene>
#include <QKeyEvent>


void Bottom::piso()
{
    //Crea la pared_izquierda
    Bottom * bottom = new Bottom ();
    scene()->addItem(bottom);
}
