#ifndef BARRA_H
#define BARRA_H
#include <QGraphicsRectItem>
#include <QObject>

class Barra: public QObject ,public QGraphicsRectItem {
    Q_OBJECT

public:
    void tabla ();
public:
    void keyPressEvent(QKeyEvent * event);

};
#endif // BARRA_H
