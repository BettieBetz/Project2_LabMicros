#ifndef PANTALLAINICIAL_H
#define PANTALLAINICIAL_H

#include <QMainWindow>
#include "pantallafinal.h" //Insercion para mostrar la pantalla final desde esta ventana
#include "game.h"          //Insercion para mostrar la pantalla de juego

namespace Ui {
class PantallaInicial;
}

class PantallaInicial : public QMainWindow
{
    Q_OBJECT

public:
    explicit PantallaInicial(QWidget *parent = 0);
    ~PantallaInicial();

private slots:
    void on_actionbutton_jugar_clicked();

private:
    Ui::PantallaInicial *ui;
    Pantallafinal *pantallafinal;  //Insercion para mostrar la pantalla final desde esta ventana

};

#endif // PANTALLAINICIAL_H
