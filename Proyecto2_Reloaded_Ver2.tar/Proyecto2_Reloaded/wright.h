#ifndef WRIGHT_H
#define WRIGHT_H
#include <QGraphicsRectItem>
#include <QObject>


class WRight: public QObject ,public QGraphicsRectItem {
    Q_OBJECT

public:
    void pared_right ();
};

#endif // WRIGHT_H
