#ifndef PANTALLAFINAL_H
#define PANTALLAFINAL_H

#include <QDialog>

namespace Ui {
class Pantallafinal;
}

class Pantallafinal : public QDialog
{
    Q_OBJECT

public:
    explicit Pantallafinal(QWidget *parent = 0);
    ~Pantallafinal();

private slots:

private:
    Ui::Pantallafinal *ui;
};

#endif // PANTALLAFINAL_H
