#include "pantallafinal.h"
#include "ui_pantallafinal.h"
#include <QThread>

Pantallafinal::Pantallafinal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Pantallafinal)
{
    ui->setupUi(this);

}

Pantallafinal::~Pantallafinal()
{
    delete ui;
}


