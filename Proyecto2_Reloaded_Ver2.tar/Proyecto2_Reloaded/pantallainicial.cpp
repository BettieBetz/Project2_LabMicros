#include "pantallainicial.h"
#include "ui_pantallainicial.h"
#include "game.h"
#include <QDebug>   //Include para pruebas
#include <QThread>  //Include para tiempo de espera en pruebas

Game *game;

PantallaInicial::PantallaInicial(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PantallaInicial)
{
    ui->setupUi(this);    
}

PantallaInicial::~PantallaInicial()
{
    delete ui;
}

QString nombre_usuario; //Se define dentro del codigo de Pantalla inicial
                        //la variable que captura el nombre de usuario.

//Accion que se realiza al hacer click en el boton "Jugar"
void PantallaInicial::on_actionbutton_jugar_clicked()
{
    nombre_usuario = ui->editext_nombre_usuario->text(); //Se captura el nombre de la caja de texto, usando metodos de UI (user interface)

    qDebug () << "Nombre capturado: " << nombre_usuario; // ### Linea para pruebas//No Fundamental para la compilacion final//

    PantallaInicial::hide(); //Esconde la pantalla inicial para dar paso a la nueva pantalla

    PantallaInicial::close();  //Cierra la pantalla inicial

    //pantallafinal = new Pantallafinal(this);    // ### Linea para pruebas//No Fundamental para la compilacion final//
    //pantallafinal -> show();                    // ### Linea para pruebas//No Fundamental para la compilacion final//

    game = new Game();
    game -> show();

}
